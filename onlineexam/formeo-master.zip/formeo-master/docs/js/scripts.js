'use strict';

((window.gitter = {}).chat = {}).options = {
  room: 'draggable/formeo'
};
