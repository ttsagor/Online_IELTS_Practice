export const IS_SITE = window.location.href.indexOf('draggable.github.io') !== -1

export const GOOGLE_ANALYTICS = 'UA-79014176-2'

