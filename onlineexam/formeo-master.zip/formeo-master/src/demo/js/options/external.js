export default {
  user: {
    isAuthenticated: true,
    userName: 'Kevin',
  },
}
