export const columnControl = {
  config: {
    label: 'column',
  },
  meta: {
    group: 'layout',
    icon: 'columns',
    id: 'layout-column',
  },
}

export default columnControl
