export const rowControl = {
  config: {
    label: 'row',
  },
  meta: {
    group: 'layout',
    icon: 'rows',
    id: 'layout-row',
  },
}

export default rowControl
