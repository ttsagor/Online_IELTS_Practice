import HeaderControl from './header'
import ParagraphControl from './paragraph'
import HRControl from './hr'

export default [HeaderControl, ParagraphControl, HRControl]
